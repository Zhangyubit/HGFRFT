function [f, label] = gsp_hgfrft_fa(G,shift)

if nargin<2
    shift = 0;
end

if ~gsp_check_hgfrft(G)
    error('GSP_hgfrft_FA needs the time dimension. Use GSP_JTV_GRAPH');
end

if isempty(G.hgfrft.NFFT)
    NFFT = G.hgfrft.T;
else
    NFFT = G.hgfrft.NFFT;
end

if shift
    f = fftshift(gsp_cfa( NFFT,G.hgfrft.fs )');
else
    f = gsp_cfa( NFFT,G.hgfrft.fs )';
end

label = '\omega';

end
