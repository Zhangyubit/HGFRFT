function Xdot = gsp_hft(G,X)
% References:
% Y. Zhang and B. Z. Li,  "The Graph Fractional Fourier Transform
% in Hilbert Space"

% Copyright (c) 2025 Y. Zhang and B. Z. Li

NFFT = G.hgfrft.NFFT;

if isempty(NFFT)
    NFFT = size(X,2);
end
    

normalize = 1/sqrt(NFFT);


    
%Xdot = fft(X,NFFT,2)*normalize;
 Xdot = X*G.hgfrft.Va;
end