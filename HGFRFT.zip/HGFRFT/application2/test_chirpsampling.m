clc;
clear;

gsp_start;

% Load the USA graph and set up the adjacency matrix
G1 = gsp_usa();
G1.W = full(G1.W);

% Set the number of nodes for the cycle graph
N_cycle = 200;
G2 = gsp_cycle(N_cycle); 

%% ====== Example ====== %%
% Number of nodes in graphs
N = G1.N;
T = G2.N;

% Perform GFRFT and DFRFT on the graphs
[Fa11, ~, Va11, ~, ~] = gfrft(G1.W, 1);
[Fa22, ~, Va22, ~, ~] = gfrft(G2.W, 1);

% Sampling and bandwidth parameters
ST = 26;  SG = 6; % Sampling points
KT = 26;  KG = 6; % Bandwidth

% ======== Graph Signal ========
load testX.mat

% Define a vertex-domain bandlimited operator
filter1 = ones(1, N);
filter1((KG + 1):N) = 0; % Spectral bandwidth restriction
Filter1 = diag(filter1);
B1 = Va11 * Filter1 * Fa11; % HGFRFT matrix with bandpass filter

% Define a Hilbert space bandlimited operator
filter2 = ones(1, T);
filter2((KT + 1):T) = 0; % Spectral bandwidth restriction
Filter2 = diag(filter2);
B2 = Va22 * Filter2 * Fa22; % GLCT matrix with bandpass filter

% Apply bandlimited operators to the signal
Y = B1 * X * B2; % Bandlimited signal

%% ======= Sampling ======= %%
% Define the range for alpha and beta
alpha_values = 0:0.1:1;
beta_values = 0:0.1:1;

% Initialize the error matrix
errorMatrix = zeros(length(alpha_values), length(beta_values));

% Loop through alpha and beta values to compute reconstruction error
for i = 1:length(alpha_values)
    for j = 1:length(beta_values)
        alpha = alpha_values(i);
        beta = beta_values(j);
        
        % Perform GFRFT and DFRFT with varying alpha and beta
        [Fa1, ~, Va1, ~, ~] = gfrft(G1.W, alpha);
        [Fa2, ~, Va2, ~, ~] = gfrft(G2.W, beta);

        % Select sampling points using the greedy max-min singular value approach
        V1k = Va1(:, 1:KG); % First KG columns of GFRFT matrix
        V2k = Va2(:, 1:KT); % First KT columns of DFRFT matrix
        [sel_G, sel_T] = greedyMaxMinSingular(V1k, V2k, SG, ST, N, T);

        % Reconstruct the signal
        [~, ~, ~, ~, Sig_rec, ~] = signal_REC(sel_G, sel_T, B1, B2, Y);

        % Compute NMSE and store it in the error matrix
        errorMatrix(i, j) = norm(abs(Sig_rec - Y));
    end
end

% 3D visualization of the reconstruction error
[A, B] = meshgrid(alpha_values, beta_values); % Create a grid for alpha and beta
figure;
surf(A, B, errorMatrix'); % Plot 3D surface of the error matrix
xlabel('\alpha');
ylabel('\beta');
zlabel('Error');
title('Signal Reconstruction Error with varying \alpha and \beta', 'FontSize', 20); % Set title font size
colorbar;
grid on;

% Find the minimum error and corresponding indices
[minError, idx] = min(errorMatrix(:)); % Minimum error value
[minRow, minCol] = ind2sub(size(errorMatrix), idx); % Indices of the minimum error

% Retrieve corresponding alpha and beta values
minAlpha = alpha_values(minRow);
minBeta = beta_values(minCol);

% Heatmap for error visualization
figure;
imagesc(alpha_values, beta_values, errorMatrix');
xlabel('\alpha');
ylabel('\beta');
title('Error Heatmap');
colorbar;