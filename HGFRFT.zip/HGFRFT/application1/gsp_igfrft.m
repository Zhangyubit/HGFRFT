function [f] = gsp_igfrft(G,f_hat,a)

% References:
% Y. Zhang and B. Z. Li,  "The Graph Fractional Fourier Transform
% in Hilbert Space"

% Copyright (c) 2025 Y. Zhang and B. Z. Li

[V,L] = eig(full(G.W)); 
[~,Index] = sort(diag(L),'descend'); 
V = V(:,Index);
F = inv(V);

[P,J] = eig(F); %
[~,Index] = sort(diag(J),'descend'); 
J = J(Index,Index);
P = P(:,Index);
Fa = P*diag(diag(J).^a)/P;
Va = inv(Fa);
s = size(f_hat);

if ~isnumeric(G);
    if ~gsp_check_fourier(G)
       error(['GSP_IGFRFT: You need first to compute the Fractional Fourier basis\n',...
           'You can do it with the function gsp_compute_fourier_basis']);
    end
    
    % U = G.U;
    f=reshape(Va * reshape(f_hat,G.N,[]),s);
else
    % U = G;
    f=reshape(G * reshape(f_hat,G.N,[]),s);
end