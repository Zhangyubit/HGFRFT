% Optimal Sampling Operator via Greedy Algorithm
% Input: M is sample size,VK is the first K columns of V
% Output: Indices of the sampled rows
% References:
% Y. Q. Wang, B. Z. Li, and Q. Y. Cheng, "The fractional Fourier transform 
% on graphs," in Proc. Asia-Pacific Signal Inf. Process. Assoc. Annu. Summit 
% Conf. (APSIPA ASC)}, 2017, pp. 105–110.

% Copyright (c) 2025 Y. Zhang and B. Z. Li
function [samp_rows,ss] = op_samp(M,VK)
samp_rows = [];
other_rows = 1:size(VK,1);
m = 0;
maxs = 0;
for count = 1:M
    for i = other_rows
        s = svd(VK([samp_rows,i],:));
        if s(end) > maxs % find the biggest minimun singular value
            maxs = s(end);
            m = i;
        end
    end
    samp_rows(count) = m;
    other_rows(other_rows==m) = [];
    maxs = 0;
end
ss = s(end);
samp_rows = sort(samp_rows,'ascend');