% Network and propagation parameter settings
num_nodes = 500; % Number of nodes
avg_degree = 12; % Average degree of the Enron network
lambda_I = 1; % Infection rate
lambda_R = 0.5; % Recovery rate
T = 100; % Observation time period

% Step 1: Generate the network and node infection states
% Create a random adjacency matrix to simulate the network
A = rand(num_nodes) < avg_degree / num_nodes; % Random graph
A = triu(A, 1); A = A + A'; % Make the graph undirected

% Generate infection and recovery times
infected = zeros(num_nodes, T); % Initialize infection matrix
for v = 1:num_nodes
    t_infect = -log(rand) / lambda_I; % Initial infection time
    while t_infect < T
        infected(v, ceil(t_infect)) = 1; % Node becomes infected
        t_recover = -log(rand) / lambda_R; % Recovery time
        t_infect = t_infect + t_recover + -log(rand) / lambda_I; % Update infection time
    end
end

% Step 2: Perform HGFRFT and TV transform spectral analysis

% HGFRFT - Continuous F-transform in the time domain
f_HGFRFT = zeros(num_nodes, T);
for v = 1:num_nodes
    % Approximate HGFRFT using the sinc function
    f_HGFRFT(v, :) = sinc(linspace(-pi, pi, T) - infected(v, :));
end

% Perform Fourier transform in the graph domain using eigenvectors of the adjacency matrix
[V, D] = eig(A); % Graph Laplacian eigen decomposition
f_HGFRFT_spectrum = abs(V' * f_HGFRFT);

% TV Transform - Discrete Fourier transform in the time domain
f_TV_transform = zeros(num_nodes, T);
for t = 1:T
    f_TV_transform(:, t) = infected(:, t);
end

% Perform discrete Fourier transform in time and graph domains
f_TV_transform_spectrum = abs(fft(f_TV_transform, [], 2)); % Time domain FFT
f_TV_transform_spectrum = abs(V' * f_TV_transform_spectrum); % Graph domain FFT

% Plot the spectral analysis results
figure;

% Get the number of rows in the matrix for y-axis settings
[num_rows, ~] = size(f_HGFRFT_spectrum);

subplot(1, 2, 1);
imagesc(f_HGFRFT_spectrum);
title('HGFRFT Spectrum');
xlabel('Frequency [\omega]', 'FontSize', 10);
ylabel('Eigenvalues [\lambda]', 'FontSize', 10); 
yticks(linspace(1, num_rows, 5)); % Set ticks from 1 to num_rows at intervals
yticklabels(linspace(1, 0, 5)); % Map the frequency range to 0-1
colorbar;

subplot(1, 2, 2);
imagesc(f_TV_transform_spectrum);
title('TV Transform Spectrum');
xlabel('Frequency [\omega]', 'FontSize', 10);
ylabel('Eigenvalues [\lambda]', 'FontSize', 10); 
yticks(linspace(1, num_rows, 5)); % Similarly set ticks from 1 to num_rows
yticklabels(linspace(1, 0, 5)); % Similarly map the frequency range to 0-1
colorbar;

sgtitle('Comparison of HGFRFT and TV Transform Spectra');