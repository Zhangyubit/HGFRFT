function [G]=gsp_G3(N,k)
load W
%GSP_RING  Initialize a ring graph
%   Usage:  G = gsp_ring(N);
%           G = gsp_ring(N,k);
%           G = gsp_ring();
%   Example:
%
%          G = gsp_ring(64);
%          param.show_edges = 1;
%          gsp_plot_graph(G,param);

if nargin < 1
   N = 64; 
end

if nargin < 2
    k = 1;
end

G.N=N;

if k>N/2
    error('Too many neighbors requested');
end

% Create weighted adjancency matrix 
G.W = W;

% Create coordinates
%G.coords = [1,0;0,1;-1,0;0,-1;2,0;0,2;-2,0;0,-2;3,0;0,3;-3,0;0,-3;4,0;0,4;-4,0;0,-4];

G.coords = [1,0,0;0,0,1;-1,0,0;0,0,-1;1,1,0;0,1,1;-1,1,0;0,1,-1;1,2,0;0,2,1;-1,2,0;0,2,-1;1,3,0;0,3,1;-1,3,0;0,3,-1];
G.plotting.limits = [-1.02, 1.02, -1.02, 3.02, -1.02, 1.02];

if k==1 
    G.type = 'G3';
else
    G.type = 'k-G3';
end

G = gsp_graph_default_parameters(G);

end

