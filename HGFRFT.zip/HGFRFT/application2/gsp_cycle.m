function [G] = gsp_cycle(N)
%GSP_DIRECTED_RING  Initialize a directed ring graph
%   Usage:  G = gsp_cycle(N);
%           G = gsp_cycle();
%
% Example:::
%          G = gsp_cycle(64);
%          gsp_plot_graph(G);
% 
% References:
% Y. Zhang and B. Z. Li,  "The Graph Fractional Fourier Transform
% in Hilbert Space"

% Copyright (c) 2025 Y. Zhang and B. Z. Li

if nargin < 1
   N = 64; 
end

G.N = N;

% Create weighted adjacency matrix
i_inds = 1:N;                  % indices of each node
j_inds = [N, 1:(N-1)];         % indices of the next node (cyclic)

% Only one direction is added, from node i to node i+1 (circular)
G.W = sparse(i_inds, j_inds, ones(1, N), N, N);

% Create coordinates
G.coords = [(cos((0:N-1) * (2*pi) / N))', (sin((0:N-1) * (2*pi) / N))'];
G.plotting.limits = [-1, 1, -1, 1];

G.type = 'cycle';

G = gsp_graph_default_parameters(G);

end
