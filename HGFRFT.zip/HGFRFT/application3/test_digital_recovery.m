clc; clear;

gsp_start

alpha = -1; % Fractional order parameter for FRFT
beta = 1;  % Fractional order parameter for GFRFT

% Step 1: Define graph structure, using a 2D grid graph to simulate graph signals
N = 28; % Number of graph nodes (28x28 2D grid)
G = gsp_2dgrid(N); % Generate a 2D grid graph

% Obtain GFRFT stage
L = G.L; % Compute the graph Laplacian matrix
% Alternatively, use the adjacency matrix:
% A = G.W;

% Step 2: Compute eigenvectors and eigenvalues of the graph Laplacian
k = 300; % Use the first 300 eigenvectors
[Phi, lambda] = eigs(L, k, 'smallestabs'); % Laplacian eigenvectors
Phi_beta = Phi.^(beta);

% Obtain FRFT stage
% Step 2: Define Chebyshev polynomial basis functions
B = 100; % Degree of Chebyshev polynomials
x = linspace(-1, 1, 100); % Sampling points in time/space
T = zeros(B, length(x)); % Initialize Chebyshev polynomial matrix
for n = 0:B-1
    T(n+1, :) = chebyshevT(n, x); % Compute nth Chebyshev polynomial
end
T_alpha = T.^(alpha);

% Step 3: Define signals
f0 = imread('digit0.png'); % Read the image of digit '0'
f6 = imread('digit6.png'); % Read the image of digit '6'
f0 = double(imresize(f0, [N N])); % Resize and convert to double
f6 = double(imresize(f6, [N N]));
f0_original = f0;
f6_original = f6;

% Add Gaussian noise
noise_std = 25; % Standard deviation of noise
f0_noisy = f0 + noise_std * randn(size(f0)); % Add Gaussian noise to f0
f6_noisy = f6 + noise_std * randn(size(f6)); % Add Gaussian noise to f6

f0 = f0_noisy;
f6 = f6_noisy;

% Define interpolation function to obtain signals for different x
f = @(x) f0 + (f6 - f0) * (x + 1) / 2;

% Compute projections of signals at different x
F_x = arrayfun(@(t) reshape(f(t), [], 1), x, 'UniformOutput', false);

% Step 4: Perform fractional Fourier transform and Chebyshev projection
% Initialize projection matrix
Y = zeros(B, k);

for b = 1:B
    for i = 1:k
        signal_matrix = cell2mat(F_x); % Flatten signal matrix
        projection_vector = Phi_beta(:, i)' * signal_matrix; % Project signal onto eigenvectors
        projection = T_alpha(b, :) * projection_vector'; % Compute coefficients in Chebyshev basis
        Y(b, i) = mean(projection); % Average projection results
    end
end

% Step 5: Reconstruct signals
f_reconstructed_1 = zeros(N, N);
T_x_1 = interp1(x, T_alpha', -1, 'linear', 'extrap')'; % Interpolate for x = -1

for b = 1:B
    for i = 1:k
        phi_i = Phi_beta(:, i); % Select the ith eigenvector
        contribution_1 = Y(b, i) * T_x_1(b) * phi_i; % Compute contribution to reconstructed signal
        f_reconstructed_1 = f_reconstructed_1 + reshape(contribution_1, [N, N]);
    end
end

% Reconstruct the images using the recovered coefficients
f_reconstructed_2 = zeros(N, N); % Reconstructed image for x = 1
% Interpolate Chebyshev polynomials at x = 1
T_x_2 = interp1(x, T_alpha', 1, 'linear', 'extrap')'; % Interpolate to get values at x = 1
% Reconstruct images
for b = 1:B
    for i = 1:k
        % Extract the corresponding column from Phi
        phi_i = Phi_beta(:, i); % Size: [N^2, 1]
        % Compute the contribution of the current coefficient
        contribution_2 = Y(b, i) * T_x_2(b) * phi_i;
        % Accumulate contributions to the reconstructed images
        f_reconstructed_2 = f_reconstructed_2 + reshape(contribution_2, [N, N]);
    end
end

% Display the original and reconstructed images
% Digital 0
subplot(2, 3, 1);
imshow(f0_original, []);
title('Original Image 0', 'FontSize', 16);

subplot(2, 3, 2);
imshow(f0_noisy, []);
title('Noisy Image 0', 'FontSize', 16);

subplot(2, 3, 3);
imshow(f_reconstructed_1, []);
title('HGFRFT (x = -1)', 'FontSize', 16);

% Digital 6
subplot(2, 3, 4);
imshow(f6_original, []);
title('Original Image 6', 'FontSize', 16);

subplot(2, 3, 5);
imshow(f6_noisy, []);
title('Noisy Image 6', 'FontSize', 16);

subplot(2, 3, 6);
imshow(f_reconstructed_2, []);
title('HGFRFT (x = 1)', 'FontSize', 16);
