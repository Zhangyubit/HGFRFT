% ====== Chirp Signals Explained in Figure 1 ======
close all;
% Parameters
fs = 10000; % Increase sampling frequency for smoother chirp signals
T = 0.2; % Time duration in seconds
n = round(T * fs); % Number of sample points
t = linspace(0, T, n); % Time vector

% Define parameters for different chirp signals
B_values = [100, 150, 200]; % Reduce the number of chirp signals for better clarity
f0_values = [20, 50, 80]; % Initial frequencies in Hz
mu_values = B_values / T; % Frequency modulation rates

for i = 1:length(B_values)
    % Generate the chirp signal
    B = B_values(i);
    f0 = f0_values(i);
    mu = mu_values(i);
    x = exp(2j * pi * (f0 * t + 0.5 * mu * t.^2));
    x = x.';

    % Plot the chirp signal
    figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]); % Set figure size
    plot(t, real(x), 'LineWidth', 4); % Increase line width
    xlabel('Time (s)', 'FontSize', 40); % Increase font size for x-axis label
    ylabel('Amplitude', 'FontSize', 40); % Increase font size for y-axis label
    title(sprintf('Chirp Signal %d: f0 = %d Hz, B = %d Hz', i, f0, B), 'FontSize', 40); % Add title with parameters
    grid on; % Add grid to the plot
    set(gca, 'FontSize', 40); % Adjust font size of axis ticks
end
