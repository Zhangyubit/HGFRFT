clc
clear
gsp_start % Initialize the GSP toolbox

% Test the effect of different optimal sampling operators on the HGFRT

a = 0.7; % Fractional order parameter a
b = 0.5; % Fractional order parameter b
dim1 = 4; % Size of the first dimension
dim2 = 4; % Size of the second dimension
param.vertex_size = 1000; % Set the vertex size for visualization

% Generate graphs
G1 = gsp_path(dim1); % Generate a path graph with dimension dim1
G2 = gsp_ring(dim2); % Generate a ring graph with dimension dim2
G3 = gsp_G3(16); % Generate a custom graph with 16 nodes

% Increase vertex size for better visualization
G1.plotting.vertex_size = 1000;
G2.plotting.vertex_size = 1000;
G3.plotting.vertex_size = 1000;

% Visualize the graph structures: path graph, ring graph, and product graph
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_graph(G1); % Plot the path graph G1
print('path.jpg', '-djpeg', '-r300'); % Save the path graph as an image

figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_graph(G2); % Plot the ring graph G2
print('ring.jpg', '-djpeg', '-r300'); % Save the ring graph as an image

figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_graph(G3); % Plot the custom graph G3
print('product.jpg', '-djpeg', '-r300'); % Save the custom graph as an image

% Perform Graph Fractional Fourier Transform (GFRFT) on G1 and G2
[Fa1, ~, Va1, V1, ~] = gfrft(G1.W, a); % Apply GFRFT to path graph G1 with order a
[Fa2, ~, Va2, V2, ~] = gfrft(G2.W, b); % Apply GFRFT to ring graph G2 with order b

% Construct graph signals using fractional Fourier bases of the path graph
f_path = Va1(:,1) + 0.5*Va1(:,2) + 2*Va1(:,3); % Linear combination of fractional bases

figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G1, real(f_path), param); % Plot the graph signal on the path graph
c = colorbar;
c.FontSize = 30;  
print('path_signal.jpg', '-djpeg', '-r300'); % Save the path graph signal as an image

% Construct graph signals using fractional Fourier bases of the ring graph
f_ring = Va2(:,1) + 0.5*Va2(:,2) + 2*Va2(:,3); % Linear combination of fractional bases

figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G2, real(f_ring), param); % Plot the graph signal on the ring graph
c = colorbar;
c.FontSize = 30; 
print('ring_signal.jpg', '-djpeg', '-r300'); % Save the ring graph signal as an image

% Construct the product graph using Kronecker product of G1 and G2
V = kron(V1, V2); % Kronecker product of orthogonal bases
Va = kron(Va1, Va2); % Kronecker product of fractional Fourier bases
Fa = kron(Fa1, Fa2); % Kronecker product of Fourier coefficients

% Construct graph signals
K = 4; % Set the bandwidth to 4
filter = ones(1, 16);
filter((K + 1):16) = 0; % Set spectral bandwidth
Filter = diag(filter); % Create the bandpass filter matrix
H = Va * Filter * Fa; % HGFRFT matrix with the bandpass filter

x = Va(:,1) + 0.5*Va(:,2) + 2*Va(:,3); % Graph signal based on Kronecker product of bases
x1 = H * x; % Bandlimited signal
x2 = x1;

% Sampling
[M1, ~] = op_samp(K, V(:,1:K)); % Optimal sampling of Kronecker bases
[M2, ~] = op_samp(K, Va(:,1:K)); % Optimal sampling of fractional bases

% Initialize the sampled signals as zero vectors
xs1 = zeros(dim1 * dim2, 1); 
xs2 = zeros(dim1 * dim2, 1);

% Initialize sampling matrices
Psi10 = zeros(K, dim1 * dim2); 
Psi20 = zeros(K, dim1 * dim2);

for i = 1:K
    Psi10(i, M1(i)) = 1; % Construct sampling matrix Psi10
    Psi20(i, M2(i)) = 1; % Construct sampling matrix Psi20
end

% Compute sampled signals
x10 = x1(M1); % Sampled x1
x20 = x2(M2); % Sampled x2

% Signal reconstruction
xr1 = V(:,1:K) * ((Psi10 * V(:,1:K)) \ x10); % Reconstruct signal from samples using orthogonal bases
xr2 = Va(:,1:K) * ((Psi20 * Va(:,1:K)) \ x20); % Reconstruct signal from samples using fractional bases

% Visualize graph signals and sampling
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G3, real(Va(:,1)), param); % Plot the graph signal corresponding to basis vector 1
c = colorbar;
c.FontSize = 30;  
view(0, 35);  % Set azimuth to 0 and elevation to 35
print('f1.jpg', '-djpeg', '-r300');

figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G3, real(Va(:,2)), param); % Plot the graph signal corresponding to basis vector 2
c = colorbar;
c.FontSize = 30;  
view(0, 35);
print('f2.jpg', '-djpeg', '-r300');

figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G3, real(Va(:,3)), param); % Plot the graph signal corresponding to basis vector 3
c = colorbar;
c.FontSize = 30; 
view(0, 35);
print('f3.jpg', '-djpeg', '-r300');

figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G3, real(x1), param); % Plot the graph signal x1
c = colorbar;
c.FontSize = 30;  
view(0, 35);
print('graph_signal_f.jpg', '-djpeg', '-r300');

% Set the values at sampled point positions to 1, while keeping other values at 0
xs1(M1) = 1; % For xs1
xs2(M2) = 1; % For xs2

% Plot sampling points and reconstructed signals
param1.vertex_size = 1000; % Set vertex size
param1.colorbar = 0; % Disable colorbar
param1.climits = [0 1]; % Set color limits from 0 to 1

figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G3, xs1, param1); % Plot sampled signal xs1
colormap([0 0 1; 0 0 0]); % Set colormap to blue and black
view(0, 35);
print('HGFT_sampling.jpg', '-djpeg', '-r300');

figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G3, xr1, param); % Plot reconstructed signal xr1
c = colorbar;
c.FontSize = 30; 
view(0, 35);
print('HGFT_recovery.jpg', '-djpeg', '-r300');

figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G3, xs2, param1); % Plot sampled signal xs2
colormap([0 0 1; 0 0 0]); % Set colormap to blue and black
view(0, 35);
print('HGFRFT_sampling.jpg', '-djpeg', '-r300');

figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G3, xr2, param); % Plot reconstructed signal xr2
c = colorbar;
c.FontSize = 30;  
view(0, 35);
print('HGFRFT_recovery.jpg', '-djpeg', '-r300');