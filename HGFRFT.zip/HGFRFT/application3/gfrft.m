function [Fa, F, Va, V, L] = gfrft(W, a)
% Perform the Graph Fractional Fourier Transform (GFRFT)
% Inputs:
%   W - Adjacency matrix of the graph
%   a - Fractional order of the transform
% Outputs:
%   Fa - Fractional Fourier transform matrix
%   F  - GFT matrix (inverse of eigenvector matrix)
%   Va - Inverse of the fractional Fourier transform matrix
%   V  - Eigenvector matrix of the adjacency matrix
%   L  - Eigenvalue matrix of the adjacency matrix
% References:
% Y. Q. Wang, B. Z. Li, and Q. Y. Cheng, "The fractional Fourier transform 
% on graphs," in Proc. Asia-Pacific Signal Inf. Process. Assoc. Annu. Summit 
% Conf. (APSIPA ASC)}, 2017, pp. 105-110.

% Copyright (c) 2025 Y. Zhang and B. Z. Li

[V, L] = eig(full(W)); % Eigen decomposition of the adjacency matrix
[~, Index] = sort(diag(L), 'descend'); % Sort eigenvalues in descending order
V = V(:, Index); % Reorder eigenvectors based on sorted eigenvalues
F = inv(V); % Compute the GFT matrix as the inverse of the eigenvector matrix

% Decompose the GFT matrix
[P, J] = eig(F); % Eigen decomposition of the GFT matrix
[~, Index] = sort(diag(J), 'descend'); % Sort eigenvalues of the GFT matrix
J = J(Index, Index); % Reorder eigenvalues in descending order
P = P(:, Index); % Reorder eigenvectors accordingly

% Construct the fractional Fourier transform matrix
Fa = P * diag(diag(J).^a) / P; % Fractional power of eigenvalues
Va = inv(Fa); % Compute the inverse of the fractional Fourier transform matrix
end
