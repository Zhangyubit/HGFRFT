function [S_G, S_T] = greedyMaxMinSingular(O_M_G_inv, O_K_D_inv, S_G_size, S_T_size, N, T)
% This function selects nodes for sets S_G and S_T based on maximizing
% the smallest singular value of the submatrix formed by the selected nodes.
%
% Inputs:
% O_M_G_inv: The inverse of the sampling operator for the graph domain
% O_K_D_inv: The inverse of the sampling operator for the time domain
% S_G_size: The number of nodes to be selected for S_G
% S_T_size: The number of nodes to be selected for S_T
% N: The total number of graph nodes
% T: The total number of time nodes
%
% Outputs:
% S_G: The set of selected nodes in the graph domain
% S_T: The set of selected nodes in the time domain
%
% References:
% Y. Zhang and B. Z. Li,  "The Graph Fractional Fourier Transform
% in Hilbert Space"

% Copyright (c) 2025 Y. Zhang and B. Z. Li

% Initialize the sets S_G and S_T as empty arrays
S_G = [];
S_T = [];

% Combined loop for selecting nodes for both S_G and S_T
for k = 1:(S_G_size + S_T_size)
    % Graph domain selection
    if length(S_G) < S_G_size
        % Compute the optimal node for S_G by maximizing the smallest singular value
        max_min_singular_G = -inf;
        for i = 1:N
            if ~ismember(i, S_G)
                candidate_set_G = [S_G, i];
                [~, S_G_vals, ~] = svd(O_M_G_inv(candidate_set_G, :), 'econ');
                min_singular_G = min(diag(S_G_vals));  % Smallest singular value
                if min_singular_G > max_min_singular_G
                    max_min_singular_G = min_singular_G;
                    s_G = i;
                end
            end
        end
        S_G = [S_G, s_G];
    end

    % Time domain selection
    if length(S_T) < S_T_size
        % Compute the optimal node for S_T by maximizing the smallest singular value
        max_min_singular_T = -inf;
        for j = 1:T
            if ~ismember(j, S_T)
                candidate_set_T = [S_T, j];
                [~, S_T_vals, ~] = svd(O_K_D_inv(candidate_set_T, :), 'econ');
                min_singular_T = min(diag(S_T_vals));  % Smallest singular value
                if min_singular_T > max_min_singular_T
                    max_min_singular_T = min_singular_T;
                    s_T = j;
                end
            end
        end
        S_T = [S_T, s_T];
    end
end
end