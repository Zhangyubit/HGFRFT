% Clear workspace, close all figures, and clear command window
clear; close all; clc;

% Parameter settings
num_nodes = 500;        % Number of nodes
avg_degree = 12.6;      % Average degree
alpha = 1;              % Parameter for the SI model
beta = 0.5;               % Parameter for the SI model
infection_prob = 0.02;  % Infection probability
time_steps = 50;        % Number of simulation steps

% Generate an Enron-like network
prob = avg_degree / (num_nodes - 1); % Probability of edge creation
A = rand(num_nodes) < prob;  % Generate random adjacency matrix
A = triu(A, 1);  % Ensure upper triangular part (symmetry)
A = A + A';      % Make the graph undirected

% Initialize the SI model
infected = false(num_nodes, 1);  % Infection status of nodes
infected(randi(num_nodes)) = true; % Randomly select an initial infected node

% Simulate the infection process
I = zeros(num_nodes, time_steps); % Record infection status at each time step
for t = 1:time_steps
    I(:, t) = infected;
    % Calculate infection spread
    new_infections = (A * infected) > 0 & ~infected; % Infection by neighbors
    infected = infected | (rand(num_nodes, 1) < infection_prob & new_infections);
end

% GFRFT and JFRFT analysis

% Compute GFRFT with beta order
[Fa, ~, Phi, ~, ~] = gfrft(A, beta);  % Eigenvalue decomposition of adjacency matrix

% Compute FRFT in Hilbert space with alpha order
f_HGFRFT = zeros(size(I));
for v = 1:size(I, 1)
    t = linspace(0, 2 * pi, size(I, 2));  % Time range for the graph signal
    rect_func = double(abs(t - I(v, :)) <= 0.1);  % Rectangular function (unit impulse)
    f_HGFRFT(v, :) = myfrft(rect_func, alpha);  % Apply FRFT to the rectangular function
end
% Compute HGFRFT spectrum with alpha and beta orders
HGFRFT_spectra = abs(Phi' * f_HGFRFT);  % Frequency analysis by multiplying Phi with FRFT results

% Compute DFRFT in discrete time domain with alpha order
f_TV_transform = zeros(size(I));
time_slots = 20;  % Number of time slots for division
for v = 1:size(I, 1)
    for tt = 1:time_slots
        % Calculate the mean value within each time slot
        slot_start = floor((tt - 1) * size(I, 2) / time_slots) + 1;
        slot_end = floor(tt * size(I, 2) / time_slots);
        f_TV_transform(v, tt) = mean(I(v, slot_start:slot_end));  % Mean within slot
    end
end

% Apply DFRFT to the time slot means
f_TV_transform_freq = zeros(size(I));
for v = 1:size(I, 1)
    f_TV_transform_freq(v, :) = disFrFT(I(v, :), alpha, 2);  % Apply DFRFT to each signal
end

% Compute JFRFT spectrum with alpha and beta orders
TV_spectra = abs(Phi' * f_TV_transform_freq);  % Frequency analysis for JFRFT

% Plot HGFRFT spectrum analysis results
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
imagesc(HGFRFT_spectra.');  % Transpose data for better visualization
xlabel('Graph Eigenvalue Index', 'FontSize', 30);
ylabel('Fourier Frequency', 'FontSize', 30);
set(gca, 'FontSize', 30);
title('HGFRFT Spectrum', 'FontSize', 30);

% Plot JFRFT spectrum analysis results
[num_rows, ~] = size(TV_spectra);
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
imagesc(TV_spectra.');  % Transpose data for better visualization
xlabel('Graph Eigenvalue Index', 'FontSize', 30);
ylabel('Fourier Frequency', 'FontSize', 30);
set(gca, 'FontSize', 30);
title('JFRFT Spectrum', 'FontSize', 30);
