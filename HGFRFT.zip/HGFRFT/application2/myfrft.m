function Faf = myfrft(f, a)
% Fractional Fourier Transform function
% Input: f - original signal, a - fractional order
% Output: Faf - fractional Fourier transform of order 'a'

N = length(f); % Total number of samples
shft = rem((0:N-1)+fix(N/2),N)+1; % Equivalent to fftshift(1:N), flips coordinate axes
sN = sqrt(N); % Scaling factor as per the discrete Fourier transform definition
a = mod(a, 4); % Ensure periodicity of 'a' within [0, 4]

% Special cases handled directly
if (a == 0), Faf = f; return; end % Identity transform
if (a == 2), Faf = flipud(f); return; end % Time reversal f(-x)
if (a == 1), Faf(shft,1) = fft(f(shft)) / sN; return; end % Fourier transform
if (a == 3), Faf(shft,1) = ifft(f(shft)) * sN; return; end % Inverse Fourier transform

% Adjust 'a' to fall within 0.5 < a < 1.5 using additivity
if (a > 2.0), a = a - 2; f = flipud(f); end % Reflect for a = 2
if (a > 1.5), a = a - 1; f(shft,1) = fft(f(shft)) / sN; end % Apply Fourier transform for a = 1
if (a < 0.5), a = a + 1; f(shft,1) = ifft(f(shft)) * sN; end % Apply inverse Fourier transform for a = -1

% Begin the main fractional Fourier transform
alpha = a * pi / 2; % Transform angle
tana2 = tan(alpha / 2); % Tangent of half the angle
sina = sin(alpha); % Sine of the angle

% Expand signal to 4N using Shannon interpolation
f = [zeros(N-1,1); interp(f); zeros(N-1,1)];
% Linear chirp pre-modulation (corresponds to Eq. 29 in the original paper)
chrp = exp(-1i * pi / N * tana2 / 4 * (-2 * N + 2 : 2 * N - 2)'.^2);
f = chrp .* f;

% Linear chirp convolution
c = pi / N / sina / 4;
Faf = fconv(exp(1i * c * (-(4 * N - 4) : 4 * N - 4)'.^2), f);
Faf = Faf(4 * N - 3 : 8 * N - 7) * sqrt(c / pi);

% Linear chirp post-modulation
Faf = chrp .* Faf;

% Multiply by the initial scaling factor A_Phi
Faf = exp(-1i * (1 - a) * pi / 4) * Faf(N:2:end-N+1);
end

function xint = interp(x) % Shannon interpolation
% Performs sinc interpolation
N = length(x); % Length of the input signal
y = zeros(2 * N - 1, 1); % Zero-pad for interpolation
y(1:2:2 * N - 1) = x; % Insert original signal values
xint = fconv(y(1:2 * N - 1), sinc([-(2 * N - 3):(2 * N - 3)]' / 2)); % Convolution with sinc
xint = xint(2 * N - 2:end - 2 * N + 3); % Remove zero-padding
end

function z = fconv(x, y) % Fast convolution using FFT
% Efficient convolution via FFT
N = length([x(:); y(:)]) - 1; % Length of the convolution result
P = 2^nextpow2(N); % Zero-padding to the next power of 2
z = ifft(fft(x, P) .* fft(y, P)); % Multiply in frequency domain for convolution
z = z(1:N); % Trim the result to the original length
end
