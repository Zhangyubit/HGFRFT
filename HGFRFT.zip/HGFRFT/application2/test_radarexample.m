clc; clear

gsp_start
% Parameters
fs = 1000; % Sampling frequency (Hz)
T = 0.2;   % Time duration (seconds)
B = 150;   % Initial bandwidth (Hz)
f0 = 50;   % Initial frequency (Hz)

n = round(T * fs); % Number of sampling points
t = linspace(0, T, n); % Time vector

% Initialize the matrix X
X = zeros(48, n);

% Generate 48 different chirp radar signals
for i = 1:48
    % Each signal has a unique initial frequency and bandwidth
    f0_i = f0 + i * 5; % Initial frequency for each signal
    B_i = B + i * 10;  % Bandwidth for each signal
    
    % Update frequency modulation rate
    mu_i = B_i / T;
    
    % Generate the chirp signal
    x = exp(2j * pi * (f0_i * t + 0.5 * mu_i * t.^2));
    
    % Store the real part of the signal in matrix X
    X(i, :) = real(x); 
end
 
% Select vertices to analyze
selected_vertices = [16, 32, 48];

%% Perform FRFT and plot the results
for i = 1:length(selected_vertices)
    idx = selected_vertices(i); % Index of the current vertex
    
    % Plot the time-domain signal
    figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
    plot(t, X(idx, :));
    xlabel('Time (s)', 'FontSize', 30);
    ylabel('Amplitude', 'FontSize', 30);
    f0_i = f0 + idx * 5; % Initial frequency for the current signal
    B_i = B + idx * 10;  % Bandwidth for the current signal
    title(['Vertex ', num2str(idx), ': f0 = ', num2str(f0_i), ' Hz, B = ', num2str(B_i), ' Hz'], ...
        'FontSize', 30, 'FontWeight', 'bold');
    set(gca, 'FontSize', 30); % Adjust axis font size
    
    % Fourier Transform (FFT)
    figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
    X_dft = fftshift(fft(X(idx, :)) / n); % Perform FFT and normalize
    f = linspace(-fs/2, fs/2, n); % Frequency axis
    plot(f, abs(X_dft));
    xlabel('Frequency (Hz)', 'FontSize', 30);
    ylabel('Magnitude', 'FontSize', 30);
    title('Magnitude Spectrum of FT', 'FontSize', 30, 'FontWeight', 'bold');
    set(gca, 'FontSize', 30); % Adjust axis font size
    
    % Compute the fractional order \( \alpha \), dynamically based on \( B_i \)
    k = B_i / fs; % Normalized frequency modulation rate
    alpha = acot(k) / (pi/2); % Compute fractional order \( \alpha \) based on \( k \)
    
    % Fractional Fourier Transform (FRFT)
    figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
    X_frft = myfrft(X(idx, :), alpha); % Assuming the function myfrft is implemented
    plot(f, abs(X_frft));
    xlabel('Frequency (Hz)', 'FontSize', 30);
    ylabel('Magnitude', 'FontSize', 30);
    title(['Magnitude Spectrum of FRFT (\alpha = ', num2str(alpha), ')'], ...
        'FontSize', 30, 'FontWeight', 'bold');
    set(gca, 'FontSize', 30); % Adjust axis font size
end

%% Graph Signal Processing
% Reshape as vector matrices
f1 = X(:,1);
f20 = X(:,20);
f50 = X(:,50);

% Graph structure (using the US map as an example)
G = gsp_usa();  % Load graph signal structure
N = G.N;  % Number of nodes
A = double(G.W);  % Adjacency matrix
A = full(A);  % Convert to full matrix
xy = G.coords;  % Get node coordinates
Px = xy(:, 1);  % X-coordinates of nodes
Py = xy(:, 2);  % Y-coordinates of nodes

% GFT and GFRFT processing
% Graph Fourier Transform (GFT) and Graph Fractional Fourier Transform (GFRFT)
beta = 0.5;  % Fractional order parameter (adjust as needed)

[Fa, F, Va, V, L] = gfrft(A, beta);  % Compute GFRFT and GFT matrices

% GFT transform
f1_gft = F * f1;
f20_gft = F * f20;
f50_gft = F * f50;

% GFRFT transform
f1_gfrft = Fa * f1;
f20_gfrft = Fa * f20;
f50_gfrft = Fa * f50;

% Graph signal at the first time point
param.vertex_size = 500;
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G, real(f1), param);  % Plot the real part of the signal
c = colorbar;
c.FontSize = 35; 
set(gca, 'XDir', 'reverse');  % Reverse the X-axis
view(90, 90);  % Set view angle
title('Radar Signal at Time 1', 'FontSize', 30, 'FontWeight', 'bold');  % Add bold title

% Graph signal at the 20th time point
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G, real(f20), param);  % Plot the real part of the signal
c = colorbar;
c.FontSize = 35; 
set(gca, 'XDir', 'reverse');  % Reverse the X-axis
view(90, 90);  % Set view angle
title('Radar Signal at Time 20', 'FontSize', 30, 'FontWeight', 'bold');  % Add bold title

% Graph signal at the 50th time point
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gsp_plot_signal(G, real(f50), param);  % Plot the real part of the signal
c = colorbar;
c.FontSize = 35; 
set(gca, 'XDir', 'reverse');  % Reverse the X-axis
view(90, 90);  % Set view angle
title('Radar Signal at Time 50', 'FontSize', 30, 'FontWeight', 'bold');  % Add bold title

% 3D plots - GFT and GFRFT signals
% ========== GFT ==========
% At time point 1
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gplot(A, xy, 'k-');  % Plot graph edges
hold on;
% Plot hollow base points
for i = 1:N
    plot3(Px(i), Py(i), 0, 'ko', 'MarkerSize', 12, 'LineWidth', 3);  % Hollow circles
end
% Plot vertical bars connecting base to extended points
for i = 1:N
    plot3([Px(i), Px(i)], [Py(i), Py(i)], [0, abs(f1_gft(i))], 'r-', 'LineWidth', 4);  % Vertical bars
end
% Plot solid extended points
for i = 1:N
    plot3(Px(i), Py(i), abs(f1_gft(i)), 'ro', 'MarkerSize', 20, 'MarkerFaceColor', 'r');  % Solid red circles
end
title('GFT of The Signal at Time 1', 'FontSize', 30, 'FontWeight', 'bold');
set(gca, 'XColor', 'none', 'YColor', 'none');
set(gca, 'XDir', 'reverse');  % Reverse X-axis
view(55, 23);  % Set view angle
zlim([0, 5.7]);  % Set Z-axis limits
grid on;
set(gca, 'FontSize', 35);  % Adjust axis label font size
zlabel('Magnitude Spectrum of GFT', 'FontSize', 30);

% Plot for time point 20
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gplot(A, xy, 'k-');  % Draw the edges of the underlying graph
hold on;
for i = 1:N
    plot3(Px(i), Py(i), 0, 'ko', 'MarkerSize', 12, 'LineWidth', 3);  % Hollow circle markers, size adjusted using MarkerSize and LineWidth
end
% Draw bars (connect the base points to the extended points)
for i = 1:N
    plot3([Px(i), Px(i)], [Py(i), Py(i)], [0, abs(f20_gft(i))], 'r-', 'LineWidth', 4);  % Red bars, thickness controlled by LineWidth
end
% Draw solid markers for the extended points
for i = 1:N
    plot3(Px(i), Py(i), abs(f20_gft(i)), 'ro', 'MarkerSize', 20, 'MarkerFaceColor', 'r');  % Solid red circle markers
end
title('GFT of The Signal at Time 20','FontSize', 30,'FontWeight', 'bold');
set(gca, 'XColor', 'none', 'YColor', 'none');
set(gca, 'XDir', 'reverse');  % Reverse the X-axis
view(55, 23);  % Set the viewing angle
zlim([0,5.7]);
grid on;
set(gca, 'FontSize', 35); % Adjust axis tick font size
zlabel('Magnitude Spectrum of GFT','FontSize', 30);

% Plot for time point 50
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gplot(A, xy, 'k-');  % Draw the edges of the underlying graph
hold on;
for i = 1:N
    plot3(Px(i), Py(i), 0, 'ko', 'MarkerSize', 12, 'LineWidth', 3);  % Hollow circle markers, size adjusted using MarkerSize and LineWidth
end
% Draw bars (connect the base points to the extended points)
for i = 1:N
    plot3([Px(i), Px(i)], [Py(i), Py(i)], [0, abs(f50_gft(i))], 'r-', 'LineWidth', 4);  % Red bars, thickness controlled by LineWidth
end
% Draw solid markers for the extended points
for i = 1:N
    plot3(Px(i), Py(i), abs(f50_gft(i)), 'ro', 'MarkerSize', 20, 'MarkerFaceColor', 'r');  % Solid red circle markers
end
title('GFT of The Signal at Time 50','FontSize', 30,'FontWeight', 'bold');
set(gca, 'XColor', 'none', 'YColor', 'none');
set(gca, 'XDir', 'reverse');  % Reverse the X-axis
view(55, 23);  % Set the viewing angle
zlim([0,5.7]);
grid on;
set(gca, 'FontSize', 35); % Adjust axis tick font size
zlabel('Magnitude Spectrum of GFT','FontSize', 30);

% ========== GFRFT ==========
% transformed signal at time point 1
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gplot(A, xy, 'k-');  % Draw the edges of the underlying graph
hold on;
for i = 1:N
    plot3(Px(i), Py(i), 0, 'ko', 'MarkerSize', 12, 'LineWidth', 3);  % Hollow circle markers, size adjusted using MarkerSize and LineWidth
end
% Draw bars (connect the base points to the extended points)
for i = 1:N
    plot3([Px(i), Px(i)], [Py(i), Py(i)], [0, abs(f1_gfrft(i))], 'b-', 'LineWidth', 4);  % Blue bars, thickness controlled by LineWidth
end
% Draw solid markers for the extended points
for i = 1:N
    plot3(Px(i), Py(i), abs(f1_gfrft(i)), 'bo', 'MarkerSize', 20, 'MarkerFaceColor', 'b');  % Solid blue circle markers
end
title('GFRFT of The Signal at Time 1','FontSize', 30,'FontWeight', 'bold');
set(gca, 'XColor', 'none', 'YColor', 'none');
set(gca, 'XDir', 'reverse');  % Reverse the X-axis
view(55, 23);  % Set the viewing angle
zlim([0,5.7]);
grid on;
set(gca, 'FontSize', 35); % Adjust axis tick font size
zlabel('Magnitude Spectrum of GFRFT','FontSize', 30);

% Plot for time point 20
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gplot(A, xy, 'k-');  % Draw the edges of the underlying graph
hold on;
for i = 1:N
    plot3(Px(i), Py(i), 0, 'ko', 'MarkerSize', 12, 'LineWidth', 3);  % Hollow circle markers, size adjusted using MarkerSize and LineWidth
end
% Draw bars (connect the base points to the extended points)
for i = 1:N
    plot3([Px(i), Px(i)], [Py(i), Py(i)], [0, abs(f20_gfrft(i))], 'b-', 'LineWidth', 4);  % Blue bars, thickness controlled by LineWidth
end
% Draw solid markers for the extended points
for i = 1:N
    plot3(Px(i), Py(i), abs(f20_gfrft(i)), 'bo', 'MarkerSize', 20, 'MarkerFaceColor', 'b');  % Solid blue circle markers
end
title('GFRFT of The Signal at Time 20','FontSize', 30,'FontWeight', 'bold');
set(gca, 'XColor', 'none', 'YColor', 'none');
set(gca, 'XDir', 'reverse');  % Reverse the X-axis
view(55, 23);  % Set the viewing angle
zlim([0,5.7]);
grid on;
set(gca, 'FontSize', 35); % Adjust axis tick font size
zlabel('Magnitude Spectrum of GFRFT','FontSize', 30);

% Plot for time point 50
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
gplot(A, xy, 'k-');  % Draw the edges of the underlying graph
hold on;
for i = 1:N
    plot3(Px(i), Py(i), 0, 'ko', 'MarkerSize', 12, 'LineWidth', 3);  % Hollow circle markers, size adjusted using MarkerSize and LineWidth
end
% Draw bars (connect the base points to the extended points)
for i = 1:N
    plot3([Px(i), Px(i)], [Py(i), Py(i)], [0, abs(f50_gfrft(i))], 'b-', 'LineWidth', 4);  % Blue bars, thickness controlled by LineWidth
end
% Draw solid markers for the extended points
for i = 1:N
    plot3(Px(i), Py(i), abs(f50_gfrft(i)), 'bo', 'MarkerSize', 20, 'MarkerFaceColor', 'b');  % Solid blue circle markers
end
title('GFRFT of The Signal at Time 50','FontSize', 30,'FontWeight', 'bold');
set(gca, 'XColor', 'none', 'YColor', 'none');
set(gca, 'XDir', 'reverse');  % Reverse the X-axis
view(55, 23);  % Set the viewing angle
zlim([0,5.7]);
grid on;
set(gca, 'FontSize', 35); % Adjust axis tick font size
zlabel('Magnitude Spectrum of GFRFT','FontSize', 30);

%% Perform HGFRFT 

% FRFT in the time domain
GT = gsp_cycle(n); % Generate a cyclic graph for FRFT
[Fa_T, ~, Va_T, ~, ~] = gfrft(GT.W, 0.1); % Compute FRFT components for time domain

% FRFT in the vertex domain
[Fa_G, ~, Va_G, ~, ~] = gfrft(A, 1); % Compute FRFT components for vertex domain

% Spectrum after DLCT
Y_time = X * Va_T; % Time domain spectrum
% Spectrum after GLCT
Y_vertex = Fa_G * X; % Vertex domain spectrum
% Spectrum after JLCT
Y = Fa_G * X * Va_T; % Joint domain spectrum

% Compute the basis for joint FRFT
Va_J = kron(Va_T, Va_G); % Kronecker product of time and vertex basis
Fa_J = kron(Fa_T, Fa_G); % Kronecker product of time and vertex transforms
KT = 26;  % Bandwidth for time domain
KG = 6;   % Bandwidth for vertex domain
K = KT * KG; % Overall joint bandwidth

% Bandlimited operator in the vertex domain
filter1 = ones(1, N); % Initialize the vertex domain filter
filter1((KG + 1):N) = 0; % Set spectral bandwidth
Filter1 = diag(filter1); % Create diagonal filter matrix
B1 = Va_G * Filter1 * Fa_G; % GFRFT matrix with bandpass filter

% Bandlimited operator in the Hilbert space (time domain)
filter2 = ones(1, n); % Initialize the time domain filter
filter2((KT + 1):n) = 0; % Set spectral bandwidth
Filter2 = diag(filter2); % Create diagonal filter matrix
B2 = Va_T * Filter2 * Fa_T; % FRFT matrix with bandpass filter

% Bandlimited signal in the joint domain
Y_band = B1 * X * B2;

% Spectrum after JLCT
hatY = Fa_G * Y_band * Va_T;

%% Non-bandlimited representation of X
% Radar time representation of the spectrum
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]); 
hold on; % Allow multiple plots on the same axes
z_offsets = [0, 50, 100]; % Adjust values to prevent overlap between graphs

for k = 1:size(X, 3) % Iterate through each channel
    % Plot the absolute value of each channel's data with z-offset, set line width to 2
    mesh(abs(X(:,:,k)) + z_offsets(k), 'LineWidth', 3); 
end

% Adjust axis label font sizes
set(gca, 'FontSize', 30);
xlabel('Radar Index', 'FontSize', 30); 
ylabel('Vertex Index', 'FontSize', 30);
zlabel('Magnitude', 'FontSize', 30);

% Set title with font size and bold styling
title('The Spectrum of Chirp Signal', 'FontSize', 30, 'FontWeight', 'bold');

% Configure colormap and colorbar
colormap(jet); 
colorbar;
c = colorbar;
c.FontSize = 30; 

% Set the 3D view angle
view(40, 15); 

hold off;

%% Non-bandlimited representation of Y
% Radar time representation of the spectrum
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]); 
hold on; % Allow multiple plots on the same axes
z_offsets = [0, 50, 100]; % Adjust these values to prevent overlapping of graphs

for k = 1:size(Y, 3) % Iterate through each channel
    % Plot the absolute value of each channel's data with z-offset, set line width to 2
    mesh(abs(Y(:,:,k)) + z_offsets(k), 'LineWidth', 3); 
end

% Adjust axis label font sizes
set(gca, 'FontSize', 30);
xlabel('Radar Index', 'FontSize', 30); 
ylabel('Vertex Index', 'FontSize', 30);
zlabel('Magnitude', 'FontSize', 30);

% Set title with font size and bold styling
title('The Spectrum of Chirp Signal by HGFRFT', 'FontSize', 30, 'FontWeight', 'bold');

% Configure colormap and colorbar
colormap(jet); 
colorbar;
c = colorbar;
c.FontSize = 30; 

% Set the 3D view angle
view(40, 15); 
hold off;

%% Plot spectrum of the signal in the time-vertex domain
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]); 
hold on; % Allow multiple plots on the same axes
z_offsets = [0, 50, 100]; % Adjust these values to prevent overlapping of graphs

for k = 1:size(hatY, 3) % Iterate through each channel
    % Plot the absolute value of each channel's data with z-offset, set line width to 2
    mesh(abs(hatY(:,:,k)) + z_offsets(k), 'LineWidth', 3); 
end

% Adjust axis label font sizes
set(gca, 'FontSize', 30);
xlabel('Radar Index', 'FontSize', 30); 
ylabel('Vertex Index', 'FontSize', 30);
zlabel('Magnitude', 'FontSize', 30);

% Set title with font size and bold styling
title('The Spectrum of the Chirp Bandlimited Signal by HGFRFT', 'FontSize', 30, 'FontWeight', 'bold');

% Configure colormap and colorbar
colormap(jet); 
colorbar;
c = colorbar;
c.FontSize = 30; 

% Set the 3D view angle
view(30, 30); 
hold off;