function [G] = gsp_usa()
    % gsp_usa  Initialize the USA 48 states graph with real coordinates
    %   Usage: G = gsp_usa();
    %

    
      %  gsp_plot_graph(G);
      %  view(90,-90)

      % figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
      % gsp_plot_graph(G);
      % set(gca, 'XDir', 'reverse'); 
      % view(55, 23); 
      % print('usa_underlying.jpg', '-djpeg', '-r300');

     
    %   Output parameters:
    %         G     : Graph structure with adjacency matrix and coordinates
    
   % References:
   % Y. Zhang and B. Z. Li,  "The Graph Fractional Fourier Transform
   % in Hilbert Space"

   % Copyright (c) 2025 Y. Zhang and B. Z. Li

% struct = {'Alabama', 'Arizona', 'Arkansas', 'California', 'Colorado', ...
%     'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Idaho', 'Illinois', ...
%     'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', ...
%     'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', ...
%     'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', ...
%     'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', ...
%     'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', ...
%     'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', ...
%     'Wisconsin', 'Wyoming'};


    %% Construction node coordinates (latitude and longitude)
    coords = [
        32.8067, -86.7911; % Alabama 1
        34.0489, -111.0937; % Arizona 2
        35.2010, -91.8318; % Arkansas 3    
        36.7783, -119.4179; % California 4
        39.5501, -105.7821; % Colorado 5
        41.6032, -73.0877; % Connecticut 6
        38.9108, -75.5277; % Delaware 7
        27.9944, -81.7603; % Florida 8
        32.1656, -82.9001; % Georgia 9
        44.0682, -114.7420; % Idaho 10
        40.6331, -89.3985; % Illinois 11
        40.2672, -86.1349; % Indiana 12
        41.8780, -93.0977; % Iowa 13
        39.0119, -98.4842; % Kansas 14
        37.8393, -84.2700; % Kentucky 15
        30.9843, -91.9623; % Louisiana 16
        45.2538, -69.4455; % Maine 17
        39.0458, -76.6413; % Maryland 18
        42.4072, -71.3824; % Massachusetts 19
        44.3148, -85.6024; % Michigan 20
        46.7296, -94.6859; % Minnesota 21
        32.3547, -89.3985; % Mississippi 22
        37.9643, -91.8318; % Missouri 23
        46.8797, -110.3626; % Montana 24
        41.4925, -99.9018; % Nebraska 25
        38.8026, -116.4194; % Nevada 26
        43.1939, -71.5724; % New Hampshire 27
        40.0583, -74.4057; % New Jersey 28
        34.5199, -105.8701; % New Mexico 29
        43.2994, -74.2179; % New York 30
        35.7596, -79.0193; % North Carolina 31
        47.5515, -101.0020; % North Dakota 32
        40.4173, -82.9071; % Ohio 33
        35.4676, -97.5164; % Oklahoma 34
        43.8041, -120.5542; % Oregon 35
        41.2033, -77.1945; % Pennsylvania 36
        41.5801, -71.4774; % Rhode Island 37
        33.8361, -81.1637; % South Carolina 38
        43.9695, -99.9018; % South Dakota 39
        35.5175, -86.5804; % Tennessee 40
        31.9686, -99.9018; % Texas 41
        39.3200, -111.0937; % Utah 42
        44.5588, -72.5778; % Vermont 43
        37.4316, -78.6569; % Virginia 44
        47.7511, -120.7401; % Washington 45
        38.5976, -80.4549; % West Virginia 46
        43.7844, -88.7879; % Wisconsin 47
        43.0759, -107.2903; % Wyoming 48
    ];

    %% Construct the adjacent relationship matrix (adjacency matrix)
A = zeros(48,48); % Adjacency matrix of the 48 states
% Alabama (1) is adjacent to Georgia (9), Florida (8), Mississippi (22), Tennessee (40)
A(1, [8, 9, 22, 40]) = 1; 
% Arizona (2) is adjacent to California (4), Nevada (26), Utah (42), New Mexico (29)
A(2, [4, 26, 29, 42]) = 1;
% Arkansas (3) is adjacent to Missouri (23), Tennessee (40), Mississippi (22), Louisiana (16), Texas (41), Oklahoma (34)
A(3, [23, 40, 22, 16, 41, 34]) = 1;
% California (4) is adjacent to Oregon (35), Nevada (26), Arizona (2)
A(4, [35, 26, 2]) = 1;
% Colorado (5) is adjacent to Wyoming (48), Nebraska (25), Kansas (14), Oklahoma (34), New Mexico (29), Utah (42)
A(5, [48, 25, 14, 34, 29, 42]) = 1;
% Connecticut (6) is adjacent to New York (30), Massachusetts (19), Rhode Island (37)
A(6, [30, 19, 37]) = 1;
% Delaware (7) is adjacent to Maryland (18), Pennsylvania (36), New Jersey (28)
A(7, [18, 36, 28]) = 1;
% Florida (8) is adjacent to Georgia (9), Alabama (1)
A(8, [9, 1]) = 1;
% Georgia (9) is adjacent to Florida (8), Alabama (1), Tennessee (40), North Carolina (31), South Carolina (38)
A(9, [8, 1, 40, 31, 38]) = 1;
% Idaho (10) is adjacent to Montana (24), Wyoming (48), Utah (42), Nevada (26), Oregon (35), Washington (45)
A(10, [24, 48, 42, 26, 35, 45]) = 1;
% Illinois (11) is adjacent to Wisconsin (47), Iowa (13), Missouri (23), Kentucky (15), Indiana (12)
A(11, [47, 13, 23, 15, 12]) = 1;
% Indiana (12) is adjacent to Illinois (11), Kentucky (15), Ohio (33), Michigan (20)
A(12, [11, 15, 33, 20]) = 1;
% Iowa (13) is adjacent to Minnesota (21), Wisconsin (47), Illinois (11), Missouri (23), Nebraska (25), South Dakota (39)
A(13, [21, 47, 11, 23, 25, 39]) = 1;
% Kansas (14) is adjacent to Nebraska (25), Missouri (23), Oklahoma (34), Colorado (5)
A(14, [25, 23, 34, 5]) = 1;
% Kentucky (15) is adjacent to Illinois (11), Indiana (12), Ohio (33), West Virginia (46), Virginia (44), Tennessee (40), Missouri (23)
A(15, [11, 12, 33, 46, 44, 40, 23]) = 1;
% Louisiana (16) is adjacent to Texas (41), Arkansas (3), Mississippi (22)
A(16, [41, 3, 22]) = 1;
% Maine (17) is adjacent to New Hampshire (27)
A(17, [27]) = 1;
% Maryland (18) is adjacent to Delaware (7), Pennsylvania (36), West Virginia (46), Virginia (44)
A(18, [7, 36, 46, 44]) = 1;
% Massachusetts (19) is adjacent to New York (30), Vermont (43), New Hampshire (27), Rhode Island (37), Connecticut (6)
A(19, [30, 43, 27, 37, 6]) = 1;
% Michigan (20) is adjacent to Ohio (33), Indiana (12), Wisconsin (47)
A(20, [33, 12, 47]) = 1;
% Minnesota (21) is adjacent to North Dakota (32), South Dakota (39), Iowa (13), Wisconsin (47) , Michigan (20)
A(21, [32, 39, 13, 47, 20]) = 1;
% Mississippi (22) is adjacent to Louisiana (16), Arkansas (3), Tennessee (40), Alabama (1)
A(22, [16, 3, 40, 1]) = 1;
% Missouri (23) is adjacent to Iowa (13), Nebraska (25), Kansas (14), Oklahoma (34), Arkansas (3), Tennessee (40), Kentucky (15), Illinois (11)
A(23, [13, 25, 14, 34, 3, 40, 15, 11]) = 1;
% Montana (24) is adjacent to North Dakota (32), South Dakota (39), Wyoming (48), Idaho (10)
A(24, [32, 39, 48, 10]) = 1;
% Nebraska (25) is adjacent to South Dakota (39), Iowa (13), Missouri (23), Kansas (14), Colorado (5), Wyoming (48)
A(25, [39, 13, 23, 14, 5, 48]) = 1;
% Nevada (26) is adjacent to Oregon (35), Idaho (10), Utah (42), Arizona (2), California (4)
A(26, [35, 10, 42, 2, 4]) = 1;
% New Hampshire (27) is adjacent to Maine (17), Massachusetts (19), Vermont (43)
A(27, [17, 19, 43]) = 1;
% New Jersey (28) is adjacent to New York (30), Pennsylvania (37), Delaware (7)
A(28, [30, 36, 7]) = 1;
% New Mexico (29) is adjacent to Arizona (2), Utah (42), Colorado (5), Oklahoma (34), Texas (41)
A(29, [2, 42, 5, 34, 41]) = 1;
% New York (30) is adjacent to Pennsylvania (36), New Jersey (28), Connecticut (6), Massachusetts (19), Vermont (43)
A(30, [36, 28, 6, 19, 43]) = 1;
% North Carolina (31) is adjacent to Georgia (9), Tennessee (40), Virginia (44), South Carolina (38)
A(31, [9, 40, 44, 38]) = 1;
% North Dakota (32) is adjacent to Minnesota (21), South Dakota (39), Montana (24)
A(32, [21, 39, 24]) = 1;
% Ohio (33) is adjacent to Pennsylvania (36), West Virginia (46), Kentucky (15), Indiana (12), Michigan (20)
A(33, [36, 46, 15, 12, 20]) = 1;
% Oklahoma (34) is adjacent to Kansas (14), Missouri (23), Arkansas (3), Texas (41), New Mexico (29), Colorado (5)
A(34, [14, 23, 3, 41, 29, 5]) = 1;
% Oregon (35) is adjacent to Washington (45), Idaho (10), Nevada (26), California (4)
A(35, [45, 10, 26, 4]) = 1;
% Pennsylvania (36) is adjacent to New York (30), New Jersey (28), Delaware (7), Maryland (18), West Virginia (46), Ohio (33)
A(36, [30, 28, 7, 18, 46, 33]) = 1;
% Rhode Island (37) is adjacent to Massachusetts (19), Connecticut (6)
A(37, [19, 6]) = 1;
% South Carolina (38) is adjacent to Georgia (9), North Carolina (31)
A(38, [9, 31]) = 1;
% South Dakota (39) is adjacent to North Dakota (32), Minnesota (21), Iowa (13), Nebraska (25), Wyoming (48), Montana (24)
A(39, [32, 21, 13, 25, 48, 24]) = 1;
% Tennessee (40) is adjacent to Kentucky (15), Virginia (44), North Carolina (31), Georgia (9), Mississippi (22), Arkansas (3), Missouri (23)
A(40, [15, 44, 31, 9, 22, 3, 23]) = 1;
% Texas (41) is adjacent to Oklahoma (34), Arkansas (3), Louisiana (16), New Mexico (29)
A(41, [34, 3, 16, 29]) = 1;
% Utah (42) is adjacent to Idaho (10), Wyoming (48), Colorado (5), New Mexico (29), Arizona (2), Nevada (26)
A(42, [10, 48, 5, 29, 2, 26]) = 1;
% Vermont (43) is adjacent to New York (30), New Hampshire (27), Massachusetts (19)
A(43, [30, 27, 19]) = 1;
% Virginia (44) is adjacent to West Virginia (46), Kentucky (15), Tennessee (39), North Carolina (31) , Maryland (18)
A(44, [46, 15, 18, 40, 31]) = 1;
% Washington (45) is adjacent to Oregon (35), Idaho (10) 
A(45, [35, 10]) = 1;
% West Virginia (46) is adjacent to Pennsylvania (36), Ohio (33), Kentucky (15), Virginia (44), Maryland (18) 
A(46, [36, 33, 15, 44, 18]) = 1;
% Wisconsin (47) is adjacent to Minnesota (21), Iowa (13), Illinois (11)  Michigan (20)
A(47, [21, 13, 11, 20]) = 1;
% Wyoming (48) is adjacent to Montana (24), South Dakota (39), Nebraska (25), Colorado (5), Idaho (10) Utah (42)
A(48, [24, 39, 25, 5, 10, 42]) = 1;
% Make sure the adjacency matrix is ​​symmetric
A = A | A'; % Make sure the adjacency matrix is ​​symmetric and all values ​​are either 0 or 1

    %% Constructing graph structure
    G = struct;
    G.W = sparse(A); 
    G.N = 48; 
    G.coords = coords; 
    G.plotting.limits = [min(coords(:,1)), max(coords(:,1)), min(coords(:,2)), max(coords(:,2))];
    G.plotting.vertex_size = 30;
    G.type = 'USA-48-states';
    G = gsp_graph_default_parameters(G);
end