function X = gsp_ihft(G,Xdot)
% References:
% Y. Zhang and B. Z. Li,  "The Graph Fractional Fourier Transform
% in Hilbert Space"

% Copyright (c) 2025 Y. Zhang and B. Z. Li

NFFT = G.hgfrft.NFFT;

if isempty(NFFT)
    NFFT = size(Xdot,2);
end
    
normalize = sqrt(NFFT);

 %X = ifft(Xdot,NFFT,2)*normalize;
  X = Xdot*G.hgfrft.Fa;   
end