function [D1,D2,check1,check2,Sig_rec,Sig_s] = signal_REC(sel_G,sel_T,B1,B2,Y) 
% Usage:  [D,check,sig_rec,sig_s] = signalrec(sel,B,y) 

% Input parameter:
% sel: Sampling set.
% B: Perfect localization matrix in the GLCT domain.
% y: Original signal after M-bandlimited.

% Output parameters:
% D: Sampling matrix.
% check: Check whether perfect localization is satisfied.
% sig_rec: Reconstructed signal.
% sig_s: Sampled signal.

% References:
% Y. Zhang and B. Z. Li, "Discrete linear canonical transform on graphs:
% Uncertainty principle and sampling" 

% Copyright (c) 2024 Y. Zhang and B. Z. Li

N = size(B1,1);
T = size(B2,1);
d1=zeros(N,1);
d1(sel_G)=1;
d2=zeros(T,1);
d2(sel_T)=1;

D1=diag(d1);
Dbar1=eye(N)-D1;

D2=diag(d2);
Dbar2=eye(T)-D2;

check1=norm(Dbar1*B1);
check2=norm(Dbar2*B2);

Sig_s = D1 * Y * D2';   %sampled signal

R1 = inv(eye(N)-Dbar1*B1);
R2 = inv(eye(T)-Dbar2*B2);

Sig_rec = R1 * Sig_s  * R2';
end