function bool = gsp_check_hgfrft(G)

bool = 0;

if ~isstruct(G)
    error('Input is not a valid Graph structure')
end

if ~isfield(G.hgfrft,'T')
    return
end

if or(~isfield(G.hgfrft,'T'),~isfield(G.hgfrft,'fs'))
    return
end

bool = 1;