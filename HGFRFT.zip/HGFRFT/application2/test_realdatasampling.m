clc; clear
% FRFT in the time domain
n = 4; % 4 seasons
GT = gsp_cycle(n); % Create a cycle graph for the time domain
T = GT.N; % Number of nodes in the time graph
[Fa_T, ~, Va_T, ~, ~] = gfrft(GT.W, 1); % Perform GFRFT on the time graph

% FRFT in the vertex domain
G = gsp_usa(); % Load the USA graph signal structure
N = G.N; % Number of nodes in the graph
G.W = double(G.W); % Convert the adjacency matrix to double
G.W = full(G.W); % Ensure the adjacency matrix is in full format
[Fa_G, ~, Va_G, ~, ~] = gfrft(G.W, 1); % Perform GFRFT on the vertex graph

% Load real-world data
load temperature.mat 
load precipitation.mat
load sunshine.mat 
load humidity.mat

X = temperature; % Use temperature data as the input signal
%X = precipitation; % Uncomment to use precipitation data
%X = sunshine;      % Uncomment to use sunshine data
%X = humidity;      % Uncomment to use humidity data

% Spectrum after DLCT
Y_time = X * Va_T; % Transform the input signal in the time domain
% Spectrum after GLCT
Y_vertex = Fa_G * X; % Transform the input signal in the vertex domain
% Spectrum after JLCT
Y = Fa_G * X * Va_T; % Transform the input signal in both domains

% Joint spectrum bases using the Kronecker product
Va_J = kron(Va_T, Va_G);
Fa_J = kron(Fa_T, Fa_G);
KT = 1;  KG = 6; % Bandwidth settings
K = KT * KG; % Joint bandwidth

% Bandlimiting operator in the vertex domain
filter1 = ones(1, N);
filter1((KG + 1):N) = 0; % Set spectral bandwidth
Filter1 = diag(filter1);
B1 = Va_G * Filter1 * Fa_G; % GFRFT matrix with bandpass filter

% Bandlimiting operator in the Hilbert space
filter2 = ones(1, n);
filter2((KT + 1):n) = 0; % Set spectral bandwidth
Filter2 = diag(filter2);
B2 = Va_T * Filter2 * Fa_T; % FRFT matrix with bandpass filter

% Bandlimited signal
Y_band = B1 * X * B2;

% Spectrum after JLCT for the bandlimited signal
hatY = Fa_G * Y_band * Va_T;

% Plot the signal spectrum in the time-vertex domain
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]); 
hold on; % Enable plotting multiple graphs in the same figure
z_offsets = [0, 50, 100]; % Adjust these values to avoid overlap
for k = 1:size(hatY, 3) % Iterate over each channel
    mesh(abs(hatY(:,:,k)) + z_offsets(k), 'LineWidth', 3); % Plot with z-offset
end
set(gca, 'FontSize', 30); % Adjust axis font size
xlabel('Radar Index', 'FontSize', 30); % Label the x-axis
ylabel('Vertex Index', 'FontSize', 30); % Label the y-axis
zlabel('Magnitude', 'FontSize', 30); % Label the z-axis
title('The Spectrum of Humidity Bandlimited Signals by HGFRFT', 'FontSize', 30); % Title
colormap(jet); % Set the colormap
colorbar;
c = colorbar;
c.FontSize = 30; 
view(30, 30); % Set 3D view angle
hold off;

%% ======= Sampling ======= %%
% Range of alpha and beta values
alpha_values = 0:0.1:1;
beta_values = 0:0.1:1;

% Initialize the error matrix
errorMatrix = zeros(length(alpha_values), length(beta_values));

% Sampling values
SG = KG; % Vertex domain sampling points
ST = KT; % Time domain sampling points

% Iterate over alpha and beta values to compute errors
for i = 1:length(alpha_values)
    for j = 1:length(beta_values)
        alpha = alpha_values(i);
        beta = beta_values(j);

        % Perform GFRFT and DFRFT
        [Fa1,~,Va1,~,~] = gfrft(G.W, alpha);
        [Fa2,~,Va2,~,~] = gfrft(GT.W, beta);

        % Sampling using selected basis
        V1k = Va1(:, 1:KG); % First KG columns of GFRFT matrix
        V2k = Va2(:, 1:KT); % First KT columns of DFRFT matrix

        [sel_G, sel_T] = greedyMaxMinSingular(V1k, V2k, SG, ST, N, T);

        % Signal reconstruction
        [~,~,~,~,Sig_rec,~] = signal_REC(sel_G, sel_T, B1, B2, Y_band);

        % Compute NMSE and store in the error matrix
        errorMatrix(i, j) = norm(abs(Sig_rec - Y_band));
    end
end

% 3D visualization of errors
[A, B] = meshgrid(alpha_values, beta_values); % Create a grid for alpha and beta
figure;
surf(A, B, errorMatrix'); % Plot the 3D error surface
xlabel('\alpha');
ylabel('\beta');
zlabel('Error');
title('Signal Reconstruction Error with varying \alpha and \beta', 'FontSize', 20); % Title with font size
colorbar;
grid on;

% Find the minimum error and its indices
[minError, idx] = min(errorMatrix(:)); % Minimum error value
[minRow, minCol] = ind2sub(size(errorMatrix), idx); % Indices of the minimum error

% Retrieve corresponding alpha and beta values
minAlpha = alpha_values(minRow);
minBeta = beta_values(minCol);

% 2D heatmap visualization of errors
figure;
imagesc(alpha_values, beta_values, errorMatrix');
xlabel('\alpha');
ylabel('\beta');
title('Error Heatmap');
colorbar;