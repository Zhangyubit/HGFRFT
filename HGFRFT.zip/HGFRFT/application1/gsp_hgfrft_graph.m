function G = gsp_hgfrft_graph(G, T, b, fs, param)
% This function defines a graph structure with parameters for HGFRFT.
% Inputs:
%   G     - Graph structure.
%   T     - Time length, must be numeric and greater than 0.
%   b     - Parameter for fractional transform.
%   fs    - Sampling frequency, must be numeric and greater than 0.
%   param - Optional structure containing additional parameters:
%           param.NFFT      - Number of FFT points (default: []).
%           param.approx    - Approximation method ('forward' by default).
%           param.extension - Whether to use extended time (default: 0).
%
% Outputs:
%   G     - Updated graph structure with HGFRFT parameters.

% References:
% Y. Zhang and B. Z. Li,  "The Graph Fractional Fourier Transform
% in Hilbert Space"

% Copyright (c) 2025 Y. Zhang and B. Z. Li

if nargin < 5
    param = struct;
end

if ~isstruct(G)
    error('G is not a valid graph');
end

if nargin < 3 || ~isnumeric(T) || T < 1
    error('Time length T must be a numeric value greater than 0');
end

if nargin < 4 || isempty(fs)
    fs = 1;
end

if ~isnumeric(fs) || fs < 0
    error('Sampling frequency fs must be a numeric value greater than 0');
end

% Set default parameters if not provided in the param structure
if ~isfield(param, 'NFFT'),      param.NFFT = []; end
if ~isfield(param, 'approx'),    param.approx = 'forward'; end
if ~isfield(param, 'extension'), param.extension = 0; end

%% PARAMETERS
% Initialize the HGFRFT field in the graph structure
G.hgfrft = struct;
G.hgfrft.T = T;                   % Set time length
G.hgfrft.fs = fs;                 % Set sampling frequency
G.hgfrft.NFFT = param.NFFT;       % Set number of FFT points
G.hgfrft.extension = param.extension; % Set time extension flag
G.hgfrft.omega = gsp_hgfrft_fa(G); % Compute frequency vector

% Determine the lag based on the extension parameter
if G.hgfrft.extension
    G.hgfrft.lag = 2 * G.hgfrft.T - 1;
else
    G.hgfrft.lag = T;
end

%% DIFFERENTIAL OPERATORS

% Create weighted adjacency matrix
k = 1;
if k == T / 2
    num_edges = T * (k - 1) + T / 2;
else
    num_edges = T * k;
end
i_inds = zeros(1, 2 * num_edges);
j_inds = zeros(1, 2 * num_edges);

% Populate indices for the adjacency matrix
all_inds = 1:T;
for i = 1:min(k, floor((T - 1) / 2))
   i_inds((i - 1) * 2 * T + 1:(i - 1) * 2 * T + T) = all_inds;
   j_inds((i - 1) * 2 * T + 1:(i - 1) * 2 * T + T) = 1 + mod(all_inds - 1 + i, T);
   i_inds((i - 1) * 2 * T + T + 1:i * 2 * T) = 1 + mod(all_inds - 1 + i, T);
   j_inds((i - 1) * 2 * T + T + 1:i * 2 * T) = all_inds;
end

if k == T / 2
   i_inds(2 * T * (k - 1) + 1:2 * T * (k - 1) + T) = all_inds;
   j_inds(2 * T * (k - 1) + 1:2 * T * (k - 1) + T) = 1 + mod(all_inds - 1 + k, T);
end

% Construct the sparse adjacency matrix
G.hgfrft.W = sparse(i_inds, j_inds, ones(1, length(i_inds)), T, T);

% Transform the adjacency matrix
[G.hgfrft.V, G.hgfrft.L] = eig(full(G.hgfrft.W)); % Eigenvalue decomposition
[~, Index] = sort(diag(G.hgfrft.L), 'descend');  % Sort eigenvalues
G.hgfrft.V = G.hgfrft.V(:, Index);               % Reorder eigenvectors
G.hgfrft.F = inv(G.hgfrft.V);                    % Compute inverse transform matrix

% Perform decomposition in Hilbert space
[G.hgfrft.P, G.hgfrft.J] = eig(G.hgfrft.F);      % Eigen decomposition of GFT matrix
[~, Index] = sort(diag(G.hgfrft.J), 'descend');  % Sort eigenvalues
G.hgfrft.J = G.hgfrft.J(Index, Index);           % Reorder eigenvalues
G.hgfrft.P = G.hgfrft.P(:, Index);               % Reorder eigenvectors

% Compute fractional transform matrices
G.hgfrft.Fa = G.hgfrft.P * diag(diag(G.hgfrft.J) .^ b) / G.hgfrft.P;
G.hgfrft.Va = inv(G.hgfrft.Fa);

end


