%% Comparison of HGFRFT and JFRFT
% Clear the workspace and command window
close all;
clear; 
clc;

% Load network data
load 'network.mat';

% Initialize the Graph Signal Processing Toolbox
gsp_start;

%% Create the connectivity graph
% Select nodes within Europe
sample = and(c(:,1) > -31.3115 , c(:,1) < 61.7221);  % Latitude range for Europe
sample = sample .* and(c(:,2) > 20.4743, c(:,2) < 80.2162);  % Longitude range for Europe
sample = logical(sample);
c = c(sample,:);

% Create a k-nearest neighbor graph and select the largest connected component
paramnn.k = 6;  % Number of nearest neighbors
G = gsp_nn_graph(c, paramnn);  % Generate the graph
[idx, Gz] = gsp_components(G);  % Find connected components
[~, ind] = max(grpstats(idx, idx, 'numel'));  % Select the largest component
G = Gz{ind};

% Add flight route graph (Afly) to the adjacency matrix
A = G.W > 0;
Afly = Afly(sample, sample);
Afly = Afly(idx == 1, idx == 1) / 100;  % Scale flight route adjacency
A = A + Afly;  % Add to the existing adjacency matrix
G = gsp_update_weights(G, A);  % Update the graph with new adjacency matrix
G = gsp_compute_fourier_basis(G);  % Compute the Fourier basis for graph signal processing

%% Simulate epidemic spread

% Set different angle combinations
alpha_values = [1, 1, 0.7]; % Different values for alpha
beta_values = [1, 0.5, 0.5]; % Different values for beta

% Define infection parameters and time
Tim = [Inf Inf];  % Immunity duration
cp  = [0.004 0.003];  % Daily infection probability

% Loop over different combinations of alpha and beta
for ii = 1:3
    % Set alpha and beta for each iteration
    alpha = alpha_values(ii); 
    beta = beta_values(ii);

    % Loop over two models: SI and SEIRS
    for model_idx = 1:2  % For SI and SEIRS models
        if model_idx == 1
            params.model = 'SI';  % SI model
        else
            params.model = 'SEIRS';  % SEIRS model
        end
        
        % Set infection parameters
        contagion_prob = cp(model_idx);  % Daily infection probability
        infection_length = 6;     % Duration of infection (days)
        params.maxTime = round(16 * 365 / 12);  % Total simulation time
        params.population = 70;  % Total population per node
        params.immunity = Tim(model_idx);  % Immunity duration
        params.latency = 2;       % Latency period
        patient_zero = randi(size(A, 1), 3, 1);  % Randomly select 3 initial infected individuals

        % Run the model simulation
        [S, I, R, E] = compartmental_epidemics(sparse(A), contagion_prob, infection_length, patient_zero, params);
        fprintf('%s model simulation complete for alpha = %f, beta = %f!\n', params.model, alpha, beta);
        
        % Normalize the number of infected individuals
        I = I - mean(I(:));  % Subtract the mean for better comparison
        T = size(I, 2);  % Number of time steps

        %% Compute GFRFT with beta order
        [Fa, ~, Phi, ~, ~] = gfrft(G.W, beta);  % Eigenvalue decomposition of the graph adjacency matrix

        %% Compute FRFT in the Hilbert space with alpha order
        f_HGFRFT = zeros(size(I));
        for v = 1:size(I, 1)
            %t = linspace(-pi, pi, size(I, 2));  % Time range for the graph signal
            t = linspace(0, 2*pi, T);  % Time range for the graph signal
            rect_func = double(abs(t - I(v, :)) <= 0.1);  % Rectangular function (unit impulse)
            f_HGFRFT(v, :) = myfrft(rect_func, alpha);  % Apply FRFT using the rectangular function
        end
        
        % Compute HGFRFT spectrum with alpha and beta orders
        HGFRFT_spectra = abs(Phi' * f_HGFRFT);  % Perform frequency analysis by multiplying Phi with FRFT

        %% Compute DFRFT in the discrete time domain with alpha order
        f_TV_transform = zeros(size(I));

        time_slots = 20;  % Number of time slots to divide the time series
        for v = 1:size(I, 1)
            for tt = 1:time_slots
                % Calculate the mean value within each time slot
                slot_start = floor((tt - 1) * T / time_slots) + 1;
                slot_end = floor(tt * T / time_slots);
                f_TV_transform(v, tt) = mean(I(v, slot_start:slot_end));  % Mean value within the slot
            end
        end

        % Apply DFRFT to the time slot means
        f_TV_transform_freq = zeros(size(I));
        for v = 1:size(I, 1)
            f_TV_transform_freq(v, :) = disFrFT(I(v, :), alpha, 2);  % Apply DFRFT to each signal
        end

        % Compute JFRFT spectrum with alpha and beta orders
        TV_spectra = abs(Phi' * f_TV_transform_freq);  % Perform frequency analysis for JFRFT

        %% Plot HGFRFT spectrum analysis result
        [num_rows, ~] = size(HGFRFT_spectra);
        figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
        imagesc(HGFRFT_spectra.');  % Transpose the data for better visualization
        xlabel('Graph Eigenvalue Index', 'FontSize', 30); 
        ylabel('Fourier Frequency', 'FontSize', 30); 
        yticks(linspace(1, num_rows, 5)); 
        yticklabels(linspace(1, -1, 5)); 
        set(gca, 'FontSize', 30); 
        title([params.model, ' Model HGFRFT Spectrum'], 'FontSize', 30,'FontWeight', 'bold');

        %% Plot JFRFT spectrum analysis result
        [num_rows, ~] = size(TV_spectra);
        figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
        imagesc(TV_spectra.');  % Transpose the data for better visualization
        xlabel('Graph Eigenvalue Index', 'FontSize', 30); 
        ylabel('Fourier Frequency', 'FontSize', 30); 
        yticks(linspace(1, num_rows, 5)); 
        yticklabels(linspace(1, -1, 5)); 
        set(gca, 'FontSize', 30); 
        title([params.model, ' Model JFRFT Spectrum'], 'FontSize', 30,'FontWeight', 'bold');
    end
end