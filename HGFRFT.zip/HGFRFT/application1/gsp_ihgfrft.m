function X = gsp_ihgfrft(G,Xhat,a)
% References:
% Y. Zhang and B. Z. Li,  "The Graph Fractional Fourier Transform
% in Hilbert Space"

% Copyright (c) 2025 Y. Zhang and B. Z. Li


if isempty(G.hgfrft.NFFT)
    NFFT = size(Xhat,2);
else
    NFFT = G.hgfrft.NFFT;
end

normalize = sqrt(NFFT);

X = gsp_igfrft(G,Xhat,a)*G.hgfrft.Fa;
   
end