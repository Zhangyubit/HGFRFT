function [f_hat] = gsp_gfrft(G, f, a)
% This function computes the Graph Fractional Fourier Transform (GFRFT).
% Inputs:
%   G - Graph structure containing the adjacency matrix.
%   f - Input signal defined on the graph's nodes.
%   a - Fractional order of the transform.
%
% Outputs:
%   f_hat - Graph Fractional Fourier transform of the input signal.
% 
% References:
% Y. Zhang and B. Z. Li,  "The Graph Fractional Fourier Transform
% in Hilbert Space"

% Copyright (c) 2025 Y. Zhang and B. Z. Li

% Step 1: Eigenvalue decomposition of the adjacency matrix
[V, L] = eig(full(G.W)); % Decompose the adjacency matrix
[~, Index] = sort(diag(L), 'descend'); % Sort eigenvalues in descending order
V = V(:, Index); % Reorder eigenvectors accordingly
F = inv(V); % Compute the inverse of the eigenvector matrix

% Step 2: Eigenvalue decomposition of the Graph Fourier Transform (GFT) matrix
[P, J] = eig(F); % Decompose the GFT matrix
[~, Index] = sort(diag(J), 'descend'); % Sort eigenvalues in descending order
J = J(Index, Index); % Reorder eigenvalues accordingly
P = P(:, Index); % Reorder eigenvectors accordingly

% Step 3: Construct the fractional transform matrices
Fa = P * diag(diag(J).^a) / P; % Compute the fractional Fourier transform matrix
Va = inv(Fa); % Compute the inverse of the fractional transform matrix

% Step 4: Apply the fractional transform to the input signal
s = size(f); % Get the size of the input signal

% Check if G is numeric or a graph structure
if ~isnumeric(G)
    % If G is a graph structure, ensure the Fourier basis is precomputed
    if ~gsp_check_fourier(G)
        error(['GSP_GFRFT: You need to first compute the Fractional Fourier basis.\n', ...
               'You can do this with the function gsp_compute_fourier_basis.']);
    end
    % Apply the fractional transform using the fractional transform matrix
    f_hat = reshape(Fa * reshape(f, G.N, []), s);
else
    % If G is numeric, apply the transform directly
    f_hat = reshape(G' * reshape(f, G.N, []), s);
end
end