%% Joint Harmonic and Compactness Analysis for Epidemic Spread Demonstration
% Clear workspace and command window
close all
clear; clc;

% Load network data
load 'network.mat';

% Initialize Graph Signal Processing (GSP) toolbox
gsp_start;

%% Create Connectivity Graph

% Select nodes limited to the European region
sample = and(c(:,1) > -31.3115, c(:,1) < 61.7221);
sample = sample .* and(c(:,2) > 20.4743, c(:,2) < 80.2162);
sample = logical(sample);
c = c(sample, :);

% Create k-nearest neighbor graph and extract the largest connected component
paramnn.k = 6;
G = gsp_nn_graph(c, paramnn);
figure();
gsp_plot_graph(G);
[idx, Gz] = gsp_components(G);
[~, ind] = max(grpstats(idx, idx, 'numel'));
G = Gz{ind};

% Add flight route connections to the graph
A = G.W > 0;
Afly = Afly(sample, sample);
Afly = Afly(idx == 1, idx == 1) / 100;
A = A + Afly;
G = gsp_update_weights(G, A);
G = gsp_compute_fourier_basis(G);

%% Simulate Epidemic Spread

% Define transmission parameters and time settings
Tim = [20 20 Inf Inf]; % Immunity durations for different scenarios
cp = [0.004 0.03 0.004 0.03]; % Daily transmission probabilities

for ii = 1:4
    contagion_prob = cp(ii); % Transmission probability per day
    infection_length = 6; % Infection duration (days)
    params.maxTime = round(16 * 365 / 12); % Total days until a cure is found
    params.population = 70; % Population per airport
    params.model = 'SEIRS'; % Epidemic model
    params.immunity = Tim(ii); % Immunity period
    params.latency = 2; % Latency period (days)
    patient_zero = randi(size(A, 1), 3, 1); % Randomly select 3 initial infected nodes
    
    % Run the epidemic model
    [S, I, R, E] = compartmental_epidemics(sparse(A), contagion_prob, infection_length, patient_zero, params);
    fprintf('Infection simulation complete!\n');
    
    % Normalize the number of infected individuals
    I = I - mean(I(:));
    X{ii} = I;
end


%% Display Results

for ii = 1:4
    % Create a new figure window
    figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
    
    % Display the number of infected individuals
    fprintf('Case %d, Number of infected: %d\n', ii, size(X{ii}, 2));
    
    % Apply Graph Fractional Fourier Transform in Hilbert Space (HGFRFT) with parameters a and b
    G = gsp_hgfrft_graph(G, size(X{ii}, 2), 1); % \beta parameter
    Ihat = gsp_hgfrft(G, X{ii}, 1); % \alpha parameter
    
    % Plot the HGFRFT results
    param.logscale = 1;
    param.dB = Inf;
    gsp_plot_hgfrft(G, Ihat, param);
    ylim([0 7]);
    xlim([0 0.25]);
    set(gca, 'FontSize', 30); % Adjust axis label font size
    xlabel('Frequency [\omega]', 'FontSize', 30);
    ylabel('Eigenvalues [\lambda]', 'FontSize', 30);
    
    % Set the plot title
    switch ii
        case 1
            title(sprintf('Low probability, Model: SEIRS, Immunity: %d days', Tim(ii)), 'FontSize', 30);
        case 2
            title(sprintf('High probability, Model: SEIRS, Immunity: %d days', Tim(ii)), 'FontSize', 30);
        case 3
            title(sprintf('Low probability, Model: SEIR, Immunity: %d days', Tim(ii)), 'FontSize', 30);
        case 4
            title(sprintf('High probability, Model: SEIR, Immunity: %d days', Tim(ii)), 'FontSize', 30);
    end
end

%% Measure Compactness
% Set parameters a, b \in [0,1], where a represents DFRFT and b represents GFRFT
a = 1; % DFRFT
b = 1; % GFRFT
ind = 1;
G = gsp_hgfrft_graph(G, size(X{ind}, 2), b);
p = 0:5:100;

Xhat = gsp_hgfrft(G, X{ind}, a);
Xdot = gsp_hft(G, X{ind});
Xtil = gsp_gfrft(G, X{ind}, a);

for ii = 1:numel(p)
    % Threshold the signal
    Xhat2 = Xhat;
    Xdot2 = Xdot;
    Xtil2 = Xtil;

    Xhat2(abs(Xhat2) < prctile(abs(Xhat2(:)), p(ii))) = 0;
    Xdot2(abs(Xdot2) < prctile(abs(Xdot2(:)), p(ii))) = 0;
    Xtil2(abs(Xtil2) < prctile(abs(Xtil2(:)), p(ii))) = 0;

    % Compute reconstruction errors
    err_hgfrft(ii) = norm(vec(X{ind} - gsp_ihgfrft(G, Xhat2, a)), 'fro') / norm(vec(X{ind}), 'fro');
    err_frft(ii) = norm(vec(X{ind} - gsp_ihft(G, Xdot2)), 'fro') / norm(vec(X{ind}), 'fro');
    err_gfrft(ii) = norm(vec(X{ind} - gsp_igfrft(G, Xtil2, a)), 'fro') / norm(vec(X{ind}), 'fro');
end

% Plot compactness results
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
semilogy(p, err_hgfrft, 'r-s', 'linewidth', 2, 'MarkerSize', 15);  % Red line
hold on;
semilogy(p, err_frft, 'b-o', 'linewidth', 2, 'MarkerSize', 15);    % Blue line
semilogy(p, err_gfrft, 'g-*', 'linewidth', 2, 'MarkerSize', 15);   % Green line
hold off;
ylim([1e-4 1]);
legend('HGFRFT of \alpha=1, \beta=0.1', 'DFRFT of \alpha=1', 'GFRFT of \beta=0.1', 'FontSize', 30, 'Location', 'southeast');
set(gca, 'FontSize', 30); % Adjust axis label font size
xlabel('Percentile of removed entries', 'FontSize', 30);
ylabel('Normalized error', 'FontSize', 30);
title('SEIRS Model', 'FontSize', 30);
grid on;