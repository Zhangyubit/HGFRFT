function a = vec(A)
a = A(:);
