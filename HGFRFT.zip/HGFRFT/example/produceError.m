clear;
clc;

dim1 = 4; % Dimension of the first graph
dim2 = 4; % Dimension of the second graph

% Create the graphs
G = gsp_G3(16);
G1 = gsp_path(dim1); % Path graph
G2 = gsp_ring(dim2); % Ring graph

% ======== Graph Signals =========
[Fa11, ~, Va11, ~, ~] = gfrft(G1.W, 0.7); % Fractional Fourier basis for G1
[Fa22, ~, Va22, ~, ~] = gfrft(G2.W, 0.5); % Fractional Fourier basis for G2

Va_k = kron(Va11, Va22); % Kronecker product of eigenvectors
Fa_k = kron(Fa11, Fa22); % Kronecker product of eigenvalues

K = 4; % Set the spectral bandwidth to 4
filter = ones(1, 16); % Initialize filter
filter((K + 1):16) = 0; % Set the filter to retain only the first K components
Filter = diag(filter);

H = Va_k * Filter * Fa_k; % Bandpass filter using HGFRFT
x = Va_k(:, 1) + 0.5 * Va_k(:, 2) + 2 * Va_k(:, 3); % Construct graph signal using Kronecker product
x1 = H * x; % Generate a bandlimited signal

% ======== Optimal Sampling =========
a_values = -0.7:0.1:2; % Range of \alpha values
b_values = -0.7:0.1:2; % Range of \beta values
numSteps_a = length(a_values); % Number of steps for \alpha
numSteps_b = length(b_values); % Number of steps for \beta

errorMatrix = zeros(numSteps_a, numSteps_b); % Initialize error matrix

% Iterate through different values of \alpha and \beta to compute error
for ai = 1:numSteps_a
    for bi = 1:numSteps_b
        a = a_values(ai);
        b = b_values(bi);
        
        % Compute fractional basis
        [~, ~, Va1, ~, ~] = gfrft(G1.W, a);
        [~, ~, Va2, ~, ~] = gfrft(G2.W, b);
        Va = kron(Va1, Va2);

        % Optimal sampling and reconstruction
        [M, ~] = op_samp(K, Va(:, 1:K)); % Sampling points
        Psi = zeros(K, 16);
        for i = 1:K
            Psi(i, M(i)) = 1; % Construct sampling matrix
        end
        
        x2 = x1(M); % Values at sampled points
        xr = Va(:, 1:K) * ((Psi * Va(:, 1:K)) \ x2); % Reconstruct the signal
        E = norm(abs(xr - x1)); % Compute reconstruction error
        
        % Store error in the matrix
        errorMatrix(ai, bi) = E;
    end
end

% ======== 3D Error Visualization ========
[A, B] = meshgrid(a_values, b_values); % Create grid for \alpha and \beta
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
surf(A, B, errorMatrix'); % Plot 3D surface of the error matrix
set(gca, 'FontSize', 30); % Adjust font size of axes
xlabel('\alpha', 'FontSize', 30);
ylabel('\beta', 'FontSize', 30);
zlabel('Error', 'FontSize', 30);
title('Signal Reconstruction Error with Varying \alpha and \beta', 'FontSize', 30); % Add title
colorbar;
grid on;

% ======== Heatmap Visualization ========
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
imagesc(a_values, b_values, errorMatrix'); % Display error as a heatmap
xlabel('\alpha', 'FontSize', 20);
ylabel('\beta', 'FontSize', 20);
title('Error Heatmap', 'FontSize', 20);
colorbar; % Add colorbar

% Load the error matrix with values ranging from 0.1 to 1
load E;

f_a = E(:, 7); % Extract error values for fixed \alpha=0.7 as \beta varies

% Plot error variation with \beta, using circle markers
figure('Units', 'pixels', 'Position', [100, 100, 1024, 768]);
plot(0.1:0.1:1, f_a, 'o-', 'Color', 'b', 'LineWidth', 3, 'MarkerSize', 10); % Plot with circle markers and line

set(gca, 'FontSize', 30); % Adjust font size of axis ticks
xlabel('\beta', 'FontSize', 30); % Label x-axis
ylabel('Error', 'FontSize', 30); % Label y-axis
title('Error vs. \beta (with fixed \alpha=0.7)', 'FontSize', 30); % Set title with increased font size
grid on; % Add grid to the plot